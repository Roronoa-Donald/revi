# Chapitre 2 — Architecture REST & modélisation des ressources

> Fiche extraite du fichier `api-rest-flask/chapitres/chapitre2.html` (438 lignes, 29.6 Ko, sha256 `94361d6ad24e`).
> Famille : **cours-api-rest-flask** · sous-type : `chapitre` · statut : **servi-canonique**.
> Cette fiche decrit ce que le document contient reellement ; les elements deduits du JavaScript sont signales `[deduit]` et references au document thematique.

## 1. Identite et acces

| Champ | Valeur |
|---|---|
| URL servie | `/api-rest-flask/chapitres/chapitre2.html` |
| Titre du document | Chapitre 2 — Architecture REST & modélisation des ressources \| API REST avec Flask B2 |
| Description meta | Chapitre 2 du cours API REST avec Flask B2 : Contraintes architecturales de Roy Fielding, conventions d’URI, verbes HTTP canoniques, sécurité et idempotence. Théorie, exemples détaillés, exercices Python exécutables, QCM corrigés. |
| Robots | indexable (defaut) |
| Langue / theme | `fr` / `defaut` |
| Chapitre (body) | 2 |
| Regle d'acces | Compte connecte + niveau B2 ou superieur + abonnement actif |
| Statut de service | servi-canonique |

## 2. Structure du document (ordre observe)

| # | Element | Classe / role | Contenu cle |
|---|---|---|---|
| 1 | nav | skip-nav | 1 liens, aria="Accès rapide" |
| 2 | h1 | — | Chapitre 2 — Architecture REST & modélisation des ressources |
| 3 | h2 | — | 1. Les fondements de l’architecture REST |
| 4 | h2 | — | 2. Conception d’URI canoniques pour les ressources |
| 5 | h2 | — | 3. Verbes HTTP et matrice CRUD |
| 6 | h2 | — | 4. Sécurité et Idempotence des opérations |
| 7 | h2 | — | 5. Exercices de code |
| 8 | h2 | — | 6. QCM — niveau examen |
| 9 | h2 | — | 7. Erreurs classiques — récapitulatif |
| 10 | h2 | — | 8. Méthodologie de résolution |
| 11 | h2 | — | 9. Révision active |
| 12 | h2 | — | 10. Test de maîtrise |
| 13 | .lab | code lab | 3 bloc(s) |
| 14 | .qcm | QCM | 8 question(s) |
| 15 | table | — | 1 tableau(x) |

## 3. Hierarchie des titres

- **H1** — Chapitre 2 — Architecture REST & modélisation des ressources
  - **H2** — 1. Les fondements de l’architecture REST
  - **H2** — 2. Conception d’URI canoniques pour les ressources
  - **H2** — 3. Verbes HTTP et matrice CRUD
  - **H2** — 4. Sécurité et Idempotence des opérations
  - **H2** — 5. Exercices de code
    - **H3** — Exercice 1 — Normalisation d’un chemin REST
    - **H3** — Exercice 2 — Choix du verbe HTTP canonique
    - **H3** — Exercice 3 — Structure d’URI : Collection vs Ressource
  - **H2** — 6. QCM — niveau examen
  - **H2** — 7. Erreurs classiques — récapitulatif
  - **H2** — 8. Méthodologie de résolution
  - **H2** — 9. Révision active
    - **H3** — Checklist de maîtrise
    - **H3** — Les 10 notions à connaître absolument
  - **H2** — 10. Test de maîtrise

## 4. Navigation et liens

| Zone | Classe | Liens |
|---|---|---|
| nav | `skip-nav` | Aller au contenu → `#content` |
| nav | `api-rest-flasknav` | Portail → `/`<br>API REST avec Flask B2 → `../index.html`<br>Sommaire → `../sommaire.html`<br>Ch. 1 → `../chapitres/chapitre1.html`<br>Ch. 2 → `../chapitres/chapitre2.html`<br>Ch. 3 → `../chapitres/chapitre3.html`<br>Ch. 4 → `../chapitres/chapitre4.html`<br>Ch. 5 → `../chapitres/chapitre5.html`<br>Ch. 6 → `../chapitres/chapitre6.html`<br>Cartes → `../chapitres/cartes.html`<br>Mémo → `../chapitres/formules.html`<br>Exercices → `../exercices/exercices.html`<br>Atelier → `../atelier.html`<br>Examen → `../chapitres/simulateur-examen.html` |

Liens sortants : **21** (externes : 0).

| Libelle | href | Cible resolue | Type |
|---|---|---|---|
| Aller au contenu | `#content` | `#content` | ancre |
| Portail | `/` | `.` | interne |
| API REST avec Flask B2 | `../index.html` | `api-rest-flask/index.html` | interne |
| Sommaire | `../sommaire.html` | `api-rest-flask/sommaire.html` | interne |
| Ch. 1 | `../chapitres/chapitre1.html` | `api-rest-flask/chapitres/chapitre1.html` | interne |
| Ch. 2 | `../chapitres/chapitre2.html` | `api-rest-flask/chapitres/chapitre2.html` | interne |
| Ch. 3 | `../chapitres/chapitre3.html` | `api-rest-flask/chapitres/chapitre3.html` | interne |
| Ch. 4 | `../chapitres/chapitre4.html` | `api-rest-flask/chapitres/chapitre4.html` | interne |
| Ch. 5 | `../chapitres/chapitre5.html` | `api-rest-flask/chapitres/chapitre5.html` | interne |
| Ch. 6 | `../chapitres/chapitre6.html` | `api-rest-flask/chapitres/chapitre6.html` | interne |
| Cartes | `../chapitres/cartes.html` | `api-rest-flask/chapitres/cartes.html` | interne |
| Mémo | `../chapitres/formules.html` | `api-rest-flask/chapitres/formules.html` | interne |
| Exercices | `../exercices/exercices.html` | `api-rest-flask/exercices/exercices.html` | interne |
| Atelier | `../atelier.html` | `api-rest-flask/atelier.html` | interne |
| Examen | `../chapitres/simulateur-examen.html` | `api-rest-flask/chapitres/simulateur-examen.html` | interne |
| Réviser avec les flashcards | `cartes.html` | `api-rest-flask/chapitres/cartes.html` | interne |
| Mémo syntaxe | `formules.html` | `api-rest-flask/chapitres/formules.html` | interne |
| Chapitre 3 — Démarrage avec Flask & Routage | `chapitre3.html` | `api-rest-flask/chapitres/chapitre3.html` | interne |

## 5. Formulaires et champs

Aucun formulaire dans cette page.
## 6. Boutons et controles interactifs

| Libelle | type | id | classes | aria-label | Etat initial | data-* |
|---|---|---|---|---|---|---|
| (icone) | button | themeToggle | `theme-toggle` | Activer le mode sombre | actif | — |
| Roy Fielding |  | — | `opt` | — | actif | data-correct=1 |
| Tim Berners-Lee |  | — | `opt` | — | actif | — |
| Linus Torvalds |  | — | `opt` | — | actif | — |
| Le serveur ne conserve aucun état client entre deux requêtes successives |  | — | `opt` | — | actif | data-correct=1 |
| Le serveur ne possède aucune base de données |  | — | `opt` | — | actif | — |
| Les requêtes n’ont pas le droit de modifier les données |  | — | `opt` | — | actif | — |
| /api/v1/etudiants/42 |  | — | `opt` | — | actif | data-correct=1 |
| /api/v1/recupererEtudiant?id=42 |  | — | `opt` | — | actif | — |
| /api/v1/get_etudiant_42 |  | — | `opt` | — | actif | — |
| PUT |  | — | `opt` | — | actif | data-correct=1 |
| PATCH |  | — | `opt` | — | actif | — |
| POST |  | — | `opt` | — | actif | — |
| La répéter plusieurs fois produit le même résultat sur le serveur |  | — | `opt` | — | actif | data-correct=1 |
| Elle ne renvoie jamais de code d’erreur 404 |  | — | `opt` | — | actif | — |
| Elle est obligatoirement chiffrée en HTTPS |  | — | `opt` | — | actif | — |
| POST |  | — | `opt` | — | actif | data-correct=1 |
| PUT |  | — | `opt` | — | actif | — |
| DELETE |  | — | `opt` | — | actif | — |
| PATCH |  | — | `opt` | — | actif | data-correct=1 |
| PUT |  | — | `opt` | — | actif | — |
| GET |  | — | `opt` | — | actif | — |
| /utilisateurs/7/commandes |  | — | `opt` | — | actif | data-correct=1 |
| /commandes_utilisateur_7 |  | — | `opt` | — | actif | — |
| /listeCommandes?user=7 |  | — | `opt` | — | actif | — |

## 7. Composants pedagogiques et etats observes

| Exercice | Langage | Hauteur | Correction | Entree standard | Titre |
|---|---|---|---|---|---|
| `fl2-c2-e1` | python | 300 | suspendue | `/API//V1/Students//` | Exercice 1 — Normalisation d’un chemin REST |
| `fl2-c2-e2` | python | 300 | suspendue | `creer` | Exercice 2 — Choix du verbe HTTP canonique |
| `fl2-c2-e3` | python | 300 | suspendue | `/utilisateurs/42` | Exercice 3 — Structure d’URI : Collection vs Ressource |

- QCM : 1 bloc(s), **8 question(s)**.
- Encadres pedagogiques : 9 (`.box`, variantes `box--*`).
- Blocs replies : 3 (`<details>`).

Etats et interactions a reconstruire :

- En-tete compact : fil d'Ariane, titre, meta (module, duree, statut gratuit).
- Encadres pedagogiques : mise en situation, objectifs, intuition, piege, methode, technique, revision.
- Tableaux de donnees et blocs pseudo-code defilables horizontalement.
- Exercices de code (`div.lab[data-lab]`) : editeur, entree standard, console a 3 onglets, tuteur IA.
- Correction suspendue si `data-grading-suspended="1"` : bouton « Validation suspendue » desactive et avis visible.
- QCM : options desactivees apres reponse, bonne reponse `is-correct`, mauvaise `is-wrong`, explication `is-shown`.
- Score QCM : `Score : n/N (p %)` + palier de maitrise (4 bandes).
- Checklist de maitrise : case `data-mark-done`, etat persiste en localStorage par chapitre.
- Navigation de bas de page : chapitre precedent / suivant.

## 8. Tableaux, code et medias

- Tableaux : 1 (0 lignes / 4 en-tetes)
- Blocs `pre` : 6 · elements `code` : 63
- SVG inline : 23 · images : 0
- Icones du sprite utilisees : `#i-house`, `#i-code`, `#i-play`, `#i-target`, `#i-lightbulb`, `#i-shield`, `#i-terminal`, `#i-warning`, `#i-compass`, `#i-pin`, `#i-cards`, `#i-file`, `#i-chart`, `#i-arrow-left`, `#i-arrow-right`
- Volume de texte : ~2143 mots · 508 noeuds HTML

## 9. Ressources chargees

- Feuilles de style : `https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600;700;800&display=swap`, `/assets/css/tokens.css`, `../assets/css/cours.css`, `/assets/css/code-lab.css`, `/assets/vendor/katex/katex.min.css`
- Scripts externes : `/assets/js/theme.js`, `../assets/js/cours.js`, `/assets/vendor/katex/katex.min.js`, `/assets/vendor/katex/auto-render.min.js`, `/assets/js/code-lab.js`
- Blocs `<style>` inline : 0 · scripts inline : 4

## 10. Classes et attributs data observes

Classes distinctes : 66. Les plus frequentes :

| Classe | Occurrences |
|---|---|
| `opt` | 24 |
| `ic` | 21 |
| `box` | 9 |
| `box__title` | 9 |
| `q` | 8 |
| `q__stem` | 8 |
| `opts` | 8 |
| `q__exp` | 8 |
| `lab__note` | 6 |
| `lab__sample-part` | 6 |
| `btn` | 4 |
| `bandrow` | 4 |
| `tag` | 3 |
| `lab` | 3 |
| `lab__head` | 3 |
| `lab__title` | 3 |
| `lab__meta` | 3 |
| `lab__lang` | 3 |
| `lab__training` | 3 |
| `badge` | 3 |

Attributs `data-*` : `data-correct` (8), `data-lab` (3), `data-exercise` (3), `data-grading-suspended` (3), `data-language` (3), `data-height` (3), `data-stdin` (3), `data-lab-starter` (3), `data-chapter` (1), `data-mark-done` (1)

## 11. Controle qualite automatique

- Titres `h1` : 1
- Boutons sans texte ni aria-label : 0
- Champs identifies sans label associe : 0
- Images sans attribut alt : 0
- Liens sans texte ni aria-label : 0
- Emoji detectes : 0 (la charte du produit les proscrit)

## 12. Renvois

- Layouts et gabarits : [04_LAYOUTS_ET_STRUCTURES.md](../../../04_LAYOUTS_ET_STRUCTURES.md)
- Composants et etats : [05_COMPOSANTS_REUTILISABLES.md](../../../05_COMPOSANTS_REUTILISABLES.md) · [10_ETATS_INTERFACE.md](../../../10_ETATS_INTERFACE.md)
- Regles d'acces : [11_ETATS_CONDITIONNELS.md](../../../11_ETATS_CONDITIONNELS.md) · [17_REGLES_METIER.md](../../../17_REGLES_METIER.md)
- Captures a produire : [22_REGISTRE_CAPTURES.md](../../../22_REGISTRE_CAPTURES.md)

*Fiche generee le 2026-11-05 par `tools/extract.mjs` ; donnees brutes dans `evidence/pages.json`.
