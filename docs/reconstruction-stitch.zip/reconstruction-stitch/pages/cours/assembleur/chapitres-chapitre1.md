# Chapitre 1 — Numération, Représentation des Données & Logique Binaire

> Fiche extraite du fichier `assembleur/chapitres/chapitre1.html` (500 lignes, 33.0 Ko, sha256 `d22182c54e53`).
> Famille : **cours-assembleur** · sous-type : `chapitre` · statut : **servi-canonique**.
> Cette fiche decrit ce que le document contient reellement ; les elements deduits du JavaScript sont signales `[deduit]` et references au document thematique.

## 1. Identite et acces

| Champ | Valeur |
|---|---|
| URL servie | `/assembleur/chapitres/chapitre1.html` |
| Titre du document | Chapitre 1 — Numération, Représentation des Données &amp; Logique Binaire \| Assembleur B2 |
| Description meta | Chapitre 1 du cours Architecture & Programmation en Assembleur B2 : Bases binaire, décimale et hexadécimale, entiers signés en complément à 2, masques binaires et décalages arithmétiques. Notions fondamentales, ateliers Python interactifs, QCM corrigés. |
| Robots | indexable (defaut) |
| Langue / theme | `fr` / `defaut` |
| Chapitre (body) | 1 |
| Regle d'acces | Libre (aucun compte) |
| Statut de service | servi-canonique |

## 2. Structure du document (ordre observe)

| # | Element | Classe / role | Contenu cle |
|---|---|---|---|
| 1 | nav | skip-nav | 1 liens, aria="Accès rapide" |
| 2 | h1 | — | Chapitre 1 — Numération, Représentation des Données & Logique Binaire |
| 3 | h2 | — | 1. Les systèmes de numération (Binaire, Hexadécimal & Décimal) |
| 4 | h2 | — | 2. Représentation des entiers relatifs : le Complément à 2 |
| 5 | h2 | — | 3. Opérations logiques fondamentales & Masquage de bits |
| 6 | h2 | — | 4. Décalages logiques vs Décalages arithmétiques (SHL, SHR, SAR) |
| 7 | h2 | — | 5. Études de cas & applications pratiques |
| 8 | h2 | — | 6. QCM — niveau examen |
| 9 | h2 | — | 7. Erreurs classiques — récapitulatif |
| 10 | h2 | — | 8. Méthodologie de résolution |
| 11 | h2 | — | 9. Révision active |
| 12 | h2 | — | 10. Test de maîtrise |
| 13 | .lab | code lab | 3 bloc(s) |
| 14 | .qcm | QCM | 8 question(s) |
| 15 | table | — | 1 tableau(x) |

## 3. Hierarchie des titres

- **H1** — Chapitre 1 — Numération, Représentation des Données & Logique Binaire
  - **H2** — 1. Les systèmes de numération (Binaire, Hexadécimal & Décimal)
  - **H2** — 2. Représentation des entiers relatifs : le Complément à 2
  - **H2** — 3. Opérations logiques fondamentales & Masquage de bits
  - **H2** — 4. Décalages logiques vs Décalages arithmétiques (SHL, SHR, SAR)
  - **H2** — 5. Études de cas & applications pratiques
    - **H3** — Exercice 1 — Masquage binaire & opérations logiques (AND, OR, XOR)
    - **H3** — Exercice 2 — Décodage du Complément à 2 (8 bits & 16 bits)
    - **H3** — Exercice 3 — Décalages logiques & arithmétiques (SHL, SHR, SAR)
  - **H2** — 6. QCM — niveau examen
  - **H2** — 7. Erreurs classiques — récapitulatif
  - **H2** — 8. Méthodologie de résolution
  - **H2** — 9. Révision active
    - **H3** — Checklist de maîtrise
    - **H3** — Les 10 notions à connaître absolument
  - **H2** — 10. Test de maîtrise

## 4. Navigation et liens

| Zone | Classe | Liens |
|---|---|---|
| nav | `skip-nav` | Aller au contenu → `#content` |
| nav | `assembleurnav` | Portail → `/`<br>Assembleur B2 → `../index.html`<br>Sommaire → `../sommaire.html`<br>Ch. 1 → `../chapitres/chapitre1.html`<br>Ch. 2 → `../chapitres/chapitre2.html`<br>Ch. 3 → `../chapitres/chapitre3.html`<br>Ch. 4 → `../chapitres/chapitre4.html`<br>Ch. 5 → `../chapitres/chapitre5.html`<br>Ch. 6 → `../chapitres/chapitre6.html`<br>Cartes → `../chapitres/cartes.html`<br>Mémo → `../chapitres/formules.html`<br>Exercices → `../chapitres/exercices.html`<br>Atelier → `../atelier.html`<br>Examen → `../chapitres/examens.html` |

Liens sortants : **21** (externes : 0).

| Libelle | href | Cible resolue | Type |
|---|---|---|---|
| Aller au contenu | `#content` | `#content` | ancre |
| Portail | `/` | `.` | interne |
| Assembleur B2 | `../index.html` | `assembleur/index.html` | interne |
| Sommaire | `../sommaire.html` | `assembleur/sommaire.html` | interne |
| Ch. 1 | `../chapitres/chapitre1.html` | `assembleur/chapitres/chapitre1.html` | interne |
| Ch. 2 | `../chapitres/chapitre2.html` | `assembleur/chapitres/chapitre2.html` | interne |
| Ch. 3 | `../chapitres/chapitre3.html` | `assembleur/chapitres/chapitre3.html` | interne |
| Ch. 4 | `../chapitres/chapitre4.html` | `assembleur/chapitres/chapitre4.html` | interne |
| Ch. 5 | `../chapitres/chapitre5.html` | `assembleur/chapitres/chapitre5.html` | interne |
| Ch. 6 | `../chapitres/chapitre6.html` | `assembleur/chapitres/chapitre6.html` | interne |
| Cartes | `../chapitres/cartes.html` | `assembleur/chapitres/cartes.html` | interne |
| Mémo | `../chapitres/formules.html` | `assembleur/chapitres/formules.html` | interne |
| Exercices | `../chapitres/exercices.html` | `assembleur/chapitres/exercices.html` | interne |
| Atelier | `../atelier.html` | `assembleur/atelier.html` | interne |
| Examen | `../chapitres/examens.html` | `assembleur/chapitres/examens.html` | interne |
| Réviser avec les flashcards | `cartes.html` | `assembleur/chapitres/cartes.html` | interne |
| Mémo syntaxe | `formules.html` | `assembleur/chapitres/formules.html` | interne |
| Chapitre 2 — Architecture du Processeur, Registres & Drapeaux d’État | `chapitre2.html` | `assembleur/chapitres/chapitre2.html` | interne |

## 5. Formulaires et champs

Aucun formulaire dans cette page.
## 6. Boutons et controles interactifs

| Libelle | type | id | classes | aria-label | Etat initial | data-* |
|---|---|---|---|---|---|---|
| (icone) | button | themeToggle | `theme-toggle` | Activer le mode sombre | actif | — |
| 0xD6 |  | — | `opt` | — | actif | data-correct=1 |
| 0xC6 |  | — | `opt` | — | actif | — |
| 0xD3 |  | — | `opt` | — | actif | — |
| 0xE6 |  | — | `opt` | — | actif | — |
| -128 à +127 |  | — | `opt` | — | actif | data-correct=1 |
| 0 à 255 |  | — | `opt` | — | actif | — |
| -127 à +128 |  | — | `opt` | — | actif | — |
| -256 à +255 |  | — | `opt` | — | actif | — |
| 0xFF (11111111b) |  | — | `opt` | — | actif | data-correct=1 |
| 0x80 (10000000b) |  | — | `opt` | — | actif | — |
| 0x01 (00000001b) |  | — | `opt` | — | actif | — |
| 0xFE (11111110b) |  | — | `opt` | — | actif | — |
| OR avec un masque ayant 1 sur le bit ciblé |  | — | `opt` | — | actif | data-correct=1 |
| AND avec un masque ayant 1 sur le bit ciblé |  | — | `opt` | — | actif | — |
| XOR avec un masque de 0 |  | — | `opt` | — | actif | — |
| NOT appliqué au registre |  | — | `opt` | — | actif | — |
| Elle est plus compacte (2 octets contre 5) et peut supprimer une dépendance sur certains p |  | — | `opt` | — | actif | data-correct=1 |
| Elle active automatiquement l’unité arithmétique flottante FPU |  | — | `opt` | — | actif | — |
| Elle permet d’écrire dans la mémoire cache L1 |  | — | `opt` | — | actif | — |
| Elle désactive les interruptions matérielles |  | — | `opt` | — | actif | — |
| SAR réplique le bit de signe (bit 7) à gauche pour préserver la valeur signée, tandis que |  | — | `opt` | — | actif | data-correct=1 |
| SHR fonctionne uniquement sur 16 bits |  | — | `opt` | — | actif | — |
| SAR inverse l’ordre des octets en mémoire |  | — | `opt` | — | actif | — |
| Il n’y a aucune différence, ce sont deux synonymes |  | — | `opt` | — | actif | — |
| 0xC0 (-64) |  | — | `opt` | — | actif | data-correct=1 |
| 0x40 (+64) |  | — | `opt` | — | actif | — |
| 0x00 (0) |  | — | `opt` | — | actif | — |
| 0xFF (-1) |  | — | `opt` | — | actif | — |
| 4 octets (32 bits) |  | — | `opt` | — | actif | data-correct=1 |
| … | | | | | | 3 de plus |

## 7. Composants pedagogiques et etats observes

| Exercice | Langage | Hauteur | Correction | Entree standard | Titre |
|---|---|---|---|---|---|
| `asm2-c1-e1` | analyse | 300 | active | `0x3F;0x0F;AND` | Exercice 1 — Masquage binaire & opérations logiques (AND, OR, XOR) |
| `asm2-c1-e2` | analyse | 300 | active | `0xFF;8` | Exercice 2 — Décodage du Complément à 2 (8 bits & 16 bits) |
| `asm2-c1-e3` | analyse | 300 | active | `0x80;1;SHL` | Exercice 3 — Décalages logiques & arithmétiques (SHL, SHR, SAR) |

- QCM : 1 bloc(s), **8 question(s)**.
- Encadres pedagogiques : 11 (`.box`, variantes `box--*`).
- Blocs replies : 3 (`<details>`).

Etats et interactions a reconstruire :

- En-tete compact : fil d'Ariane, titre, meta (module, duree, statut gratuit).
- Encadres pedagogiques : mise en situation, objectifs, intuition, piege, methode, technique, revision.
- Tableaux de donnees et blocs pseudo-code defilables horizontalement.
- Exercices de code (`div.lab[data-lab]`) : editeur, entree standard, console a 3 onglets, tuteur IA.
- Correction suspendue si `data-grading-suspended="1"` : bouton « Validation suspendue » desactive et avis visible.
- QCM : options desactivees apres reponse, bonne reponse `is-correct`, mauvaise `is-wrong`, explication `is-shown`.
- Score QCM : `Score : n/N (p %)` + palier de maitrise (4 bandes).
- Checklist de maitrise : case `data-mark-done`, etat persiste en localStorage par chapitre.
- Navigation de bas de page : chapitre precedent / suivant.

## 8. Tableaux, code et medias

- Tableaux : 1 (0 lignes / 3 en-tetes)
- Blocs `pre` : 6 · elements `code` : 38
- SVG inline : 25 · images : 0
- Icones du sprite utilisees : `#i-house`, `#i-cpu`, `#i-play`, `#i-target`, `#i-info`, `#i-warning`, `#i-book`, `#i-lightbulb`, `#i-compass`, `#i-pin`, `#i-cards`, `#i-file`, `#i-chart`, `#i-arrow-left`, `#i-arrow-right`
- Volume de texte : ~3063 mots · 469 noeuds HTML

## 9. Ressources chargees

- Feuilles de style : `https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600;700;800&display=swap`, `/assets/css/tokens.css`, `../assets/css/cours.css`, `/assets/css/code-lab.css`, `/assets/vendor/katex/katex.min.css`
- Scripts externes : `/assets/js/theme.js`, `../assets/js/cours.js`, `/assets/vendor/katex/katex.min.js`, `/assets/vendor/katex/auto-render.min.js`, `/assets/js/code-lab.js`
- Blocs `<style>` inline : 0 · scripts inline : 4

## 10. Classes et attributs data observes

Classes distinctes : 66. Les plus frequentes :

| Classe | Occurrences |
|---|---|
| `opt` | 32 |
| `ic` | 23 |
| `box` | 11 |
| `box__title` | 11 |
| `q` | 8 |
| `q__stem` | 8 |
| `opts` | 8 |
| `q__exp` | 8 |
| `btn` | 4 |
| `bandrow` | 4 |
| `tag` | 3 |
| `lab` | 3 |
| `lab__head` | 3 |
| `lab__title` | 3 |
| `lab__meta` | 3 |
| `lab__lang` | 3 |
| `lab__formative` | 3 |
| `badge` | 3 |
| `lab__body` | 3 |
| `lab__formative-notice` | 3 |

Attributs `data-*` : `data-correct` (8), `data-lab` (3), `data-exercise` (3), `data-language` (3), `data-height` (3), `data-stdin` (3), `data-lab-starter` (3), `data-chapter` (1), `data-mark-done` (1)

## 11. Controle qualite automatique

- Titres `h1` : 1
- Boutons sans texte ni aria-label : 0
- Champs identifies sans label associe : 0
- Images sans attribut alt : 0
- Liens sans texte ni aria-label : 0
- Emoji detectes : 0 (la charte du produit les proscrit)

## 12. Renvois

- Layouts et gabarits : [04_LAYOUTS_ET_STRUCTURES.md](../../../04_LAYOUTS_ET_STRUCTURES.md)
- Composants et etats : [05_COMPOSANTS_REUTILISABLES.md](../../../05_COMPOSANTS_REUTILISABLES.md) · [10_ETATS_INTERFACE.md](../../../10_ETATS_INTERFACE.md)
- Regles d'acces : [11_ETATS_CONDITIONNELS.md](../../../11_ETATS_CONDITIONNELS.md) · [17_REGLES_METIER.md](../../../17_REGLES_METIER.md)
- Captures a produire : [22_REGISTRE_CAPTURES.md](../../../22_REGISTRE_CAPTURES.md)

*Fiche generee le 2026-11-05 par `tools/extract.mjs` ; donnees brutes dans `evidence/pages.json`.
