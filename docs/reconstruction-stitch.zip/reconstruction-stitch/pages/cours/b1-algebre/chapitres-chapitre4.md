# Chapitre 4 — Espaces vectoriels et sous-espaces vectoriels

> Fiche extraite du fichier `b1-algebre/chapitres/chapitre4.html` (493 lignes, 29.2 Ko, sha256 `a065db91bc37`).
> Famille : **cours-b1-algebre** · sous-type : `chapitre` · statut : **servi-canonique**.
> Cette fiche decrit ce que le document contient reellement ; les elements deduits du JavaScript sont signales `[deduit]` et references au document thematique.

## 1. Identite et acces

| Champ | Valeur |
|---|---|
| URL servie | `/b1-algebre/chapitres/chapitre4.html` |
| Titre du document | Chapitre 4 — Espaces vectoriels et sous-espaces vectoriels \| Algèbre B1 |
| Description meta | Chapitre 4 du cours d’algèbre linéaire B1 : Axiomes d’espace vectoriel, exemples fondamentaux, critère de sous-espace et sous-espace engendré. Théorie, exemples calculés, études de cas mathématiques, QCM corrigés. |
| Robots | indexable (defaut) |
| Langue / theme | `fr` / `defaut` |
| Chapitre (body) | 4 |
| Regle d'acces | Compte connecte + niveau B1 ou superieur + abonnement actif |
| Statut de service | servi-canonique |

## 2. Structure du document (ordre observe)

| # | Element | Classe / role | Contenu cle |
|---|---|---|---|
| 1 | nav | skip-nav | 1 liens, aria="Accès rapide" |
| 2 | h1 | — | Chapitre 4 — Espaces vectoriels et sous-espaces vectoriels |
| 3 | h2 | — | 1. Définition d’un espace vectoriel |
| 4 | h2 | — | 2. Les exemples fondamentaux |
| 5 | h2 | — | 3. Sous-espaces vectoriels |
| 6 | h2 | — | 4. Sous-espace engendré, somme de sous-espaces |
| 7 | h2 | — | 5. Études de cas & applications pratiques |
| 8 | h2 | — | 6. QCM — niveau examen |
| 9 | h2 | — | 7. Erreurs classiques — récapitulatif |
| 10 | h2 | — | 8. Méthodologie de résolution |
| 11 | h2 | — | 9. Révision active |
| 12 | h2 | — | 10. Test de maîtrise |
| 13 | .lab | code lab | 3 bloc(s) |
| 14 | .qcm | QCM | 6 question(s) |
| 15 | table | — | 1 tableau(x) |

## 3. Hierarchie des titres

- **H1** — Chapitre 4 — Espaces vectoriels et sous-espaces vectoriels
  - **H2** — 1. Définition d’un espace vectoriel
  - **H2** — 2. Les exemples fondamentaux
  - **H2** — 3. Sous-espaces vectoriels
  - **H2** — 4. Sous-espace engendré, somme de sous-espaces
  - **H2** — 5. Études de cas & applications pratiques
    - **H3** — Exercice 1 — Combinaison linéaire
    - **H3** — Exercice 2 — Le vecteur appartient-il au plan engendré ?
    - **H3** — Exercice 3 — Coordonnées dans une famille
  - **H2** — 6. QCM — niveau examen
  - **H2** — 7. Erreurs classiques — récapitulatif
  - **H2** — 8. Méthodologie de résolution
  - **H2** — 9. Révision active
    - **H3** — Checklist de maîtrise
    - **H3** — Les 8 notions à connaître absolument
  - **H2** — 10. Test de maîtrise

## 4. Navigation et liens

| Zone | Classe | Liens |
|---|---|---|
| nav | `skip-nav` | Aller au contenu → `#content` |
| nav | `alnav` | Portail → `/`<br>Algèbre B1 → `../index.html`<br>Sommaire → `../sommaire.html`<br>Ch. 1 → `../chapitres/chapitre1.html`<br>Ch. 2 → `../chapitres/chapitre2.html`<br>Ch. 3 → `../chapitres/chapitre3.html`<br>Ch. 4 → `../chapitres/chapitre4.html`<br>Ch. 5 → `../chapitres/chapitre5.html`<br>Ch. 6 → `../chapitres/chapitre6.html`<br>Cartes → `../chapitres/cartes.html`<br>Mémo → `../chapitres/formules.html`<br>Exercices → `../exercices/exercices.html`<br>Atelier → `../atelier.html`<br>Examen → `../chapitres/simulateur-examen.html` |

Liens sortants : **21** (externes : 0).

| Libelle | href | Cible resolue | Type |
|---|---|---|---|
| Aller au contenu | `#content` | `#content` | ancre |
| Portail | `/` | `.` | interne |
| Algèbre B1 | `../index.html` | `b1-algebre/index.html` | interne |
| Sommaire | `../sommaire.html` | `b1-algebre/sommaire.html` | interne |
| Ch. 1 | `../chapitres/chapitre1.html` | `b1-algebre/chapitres/chapitre1.html` | interne |
| Ch. 2 | `../chapitres/chapitre2.html` | `b1-algebre/chapitres/chapitre2.html` | interne |
| Ch. 3 | `../chapitres/chapitre3.html` | `b1-algebre/chapitres/chapitre3.html` | interne |
| Ch. 4 | `../chapitres/chapitre4.html` | `b1-algebre/chapitres/chapitre4.html` | interne |
| Ch. 5 | `../chapitres/chapitre5.html` | `b1-algebre/chapitres/chapitre5.html` | interne |
| Ch. 6 | `../chapitres/chapitre6.html` | `b1-algebre/chapitres/chapitre6.html` | interne |
| Cartes | `../chapitres/cartes.html` | `b1-algebre/chapitres/cartes.html` | interne |
| Mémo | `../chapitres/formules.html` | `b1-algebre/chapitres/formules.html` | interne |
| Exercices | `../exercices/exercices.html` | `b1-algebre/exercices/exercices.html` | interne |
| Atelier | `../atelier.html` | `b1-algebre/atelier.html` | interne |
| Examen | `../chapitres/simulateur-examen.html` | `b1-algebre/chapitres/simulateur-examen.html` | interne |
| Réviser avec les flashcards | `cartes.html` | `b1-algebre/chapitres/cartes.html` | interne |
| Mémo syntaxe | `formules.html` | `b1-algebre/chapitres/formules.html` | interne |
| Chapitre 5 — Familles libres, génératrices, bases et rang | `chapitre5.html` | `b1-algebre/chapitres/chapitre5.html` | interne |

## 5. Formulaires et champs

Aucun formulaire dans cette page.
## 6. Boutons et controles interactifs

| Libelle | type | id | classes | aria-label | Etat initial | data-* |
|---|---|---|---|---|---|---|
| (icone) | button | themeToggle | `theme-toggle` | Activer le mode sombre | actif | — |
| au moins deux vecteurs |  | — | `opt` | — | actif | — |
| un élément neutre pour l’addition |  | — | `opt` | — | actif | data-correct=1 |
| une base canonique |  | — | `opt` | — | actif | — |
| les huit axiomes |  | — | `opt` | — | actif | — |
| 0 ∈ F, stabilité par addition et par scalaire |  | — | `opt` | — | actif | data-correct=1 |
| que F est fini |  | — | `opt` | — | actif | — |
| Oui |  | — | `opt` | — | actif | — |
| Non, il ne contient pas le vecteur nul |  | — | `opt` | — | actif | data-correct=1 |
| Oui, il est stable par addition |  | — | `opt` | — | actif | — |
| les vecteurs de la famille |  | — | `opt` | — | actif | — |
| toutes les combinaisons linéaires de la famille |  | — | `opt` | — | actif | data-correct=1 |
| les vecteurs orthogonaux |  | — | `opt` | — | actif | — |
| quand F = G |  | — | `opt` | — | actif | — |
| quand F ∩ G = {0} |  | — | `opt` | — | actif | data-correct=1 |
| quand F et G sont de même dimension |  | — | `opt` | — | actif | — |
| le polynôme constant 1 |  | — | `opt` | — | actif | — |
| le polynôme nul |  | — | `opt` | — | actif | data-correct=1 |
| il n’existe pas |  | — | `opt` | — | actif | — |

## 7. Composants pedagogiques et etats observes

| Exercice | Langage | Hauteur | Correction | Entree standard | Titre |
|---|---|---|---|---|---|
| `al-c4-e1` | analyse | 300 | active | `3 2 3 1 2 3 4 5 6` | Exercice 1 — Combinaison linéaire |
| `al-c4-e2` | analyse | 300 | active | `1 0 0 0 1 0 1 1 0` | Exercice 2 — Le vecteur appartient-il au plan engendré ? |
| `al-c4-e3` | analyse | 300 | active | `3 3 0 1 0 0 0 1 0` | Exercice 3 — Coordonnées dans une famille |

- QCM : 1 bloc(s), **6 question(s)**.
- Encadres pedagogiques : 11 (`.box`, variantes `box--*`).
- Blocs replies : 3 (`<details>`).

Etats et interactions a reconstruire :

- En-tete compact : fil d'Ariane, titre, meta (module, duree, statut gratuit).
- Encadres pedagogiques : mise en situation, objectifs, intuition, piege, methode, technique, revision.
- Tableaux de donnees et blocs pseudo-code defilables horizontalement.
- Exercices de code (`div.lab[data-lab]`) : editeur, entree standard, console a 3 onglets, tuteur IA.
- Correction suspendue si `data-grading-suspended="1"` : bouton « Validation suspendue » desactive et avis visible.
- QCM : options desactivees apres reponse, bonne reponse `is-correct`, mauvaise `is-wrong`, explication `is-shown`.
- Score QCM : `Score : n/N (p %)` + palier de maitrise (4 bandes).
- Checklist de maitrise : case `data-mark-done`, etat persiste en localStorage par chapitre.
- Navigation de bas de page : chapitre precedent / suivant.

## 8. Tableaux, code et medias

- Tableaux : 1 (0 lignes / 3 en-tetes)
- Blocs `pre` : 6 · elements `code` : 57
- SVG inline : 25 · images : 0
- Icones du sprite utilisees : `#i-house`, `#i-i-calculator`, `#i-play`, `#i-target`, `#i-compass`, `#i-pin`, `#i-wrench`, `#i-warning`, `#i-terminal`, `#i-book`, `#i-lightbulb`, `#i-cards`, `#i-file`, `#i-chart`, `#i-arrow-left`, `#i-arrow-right`
- Volume de texte : ~2602 mots · 468 noeuds HTML

## 9. Ressources chargees

- Feuilles de style : `https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600;700;800&display=swap`, `/assets/css/tokens.css`, `../assets/css/cours.css`, `/assets/css/code-lab.css`, `/assets/vendor/katex/katex.min.css`
- Scripts externes : `/assets/js/theme.js`, `../assets/js/cours.js`, `/assets/vendor/katex/katex.min.js`, `/assets/vendor/katex/auto-render.min.js`, `/assets/js/code-lab.js`
- Blocs `<style>` inline : 0 · scripts inline : 4

## 10. Classes et attributs data observes

Classes distinctes : 66. Les plus frequentes :

| Classe | Occurrences |
|---|---|
| `ic` | 23 |
| `opt` | 18 |
| `box` | 11 |
| `box__title` | 11 |
| `q` | 6 |
| `q__stem` | 6 |
| `opts` | 6 |
| `q__exp` | 6 |
| `btn` | 4 |
| `bandrow` | 4 |
| `tag` | 3 |
| `box--tech` | 3 |
| `lab` | 3 |
| `lab__head` | 3 |
| `lab__title` | 3 |
| `lab__meta` | 3 |
| `lab__lang` | 3 |
| `lab__formative` | 3 |
| `badge` | 3 |
| `lab__body` | 3 |

Attributs `data-*` : `data-correct` (6), `data-lab` (3), `data-exercise` (3), `data-language` (3), `data-height` (3), `data-stdin` (3), `data-lab-starter` (3), `data-chapter` (1), `data-mark-done` (1)

## 11. Controle qualite automatique

- Titres `h1` : 1
- Boutons sans texte ni aria-label : 0
- Champs identifies sans label associe : 0
- Images sans attribut alt : 0
- Liens sans texte ni aria-label : 0
- Emoji detectes : 0 (la charte du produit les proscrit)

## 12. Renvois

- Layouts et gabarits : [04_LAYOUTS_ET_STRUCTURES.md](../../../04_LAYOUTS_ET_STRUCTURES.md)
- Composants et etats : [05_COMPOSANTS_REUTILISABLES.md](../../../05_COMPOSANTS_REUTILISABLES.md) · [10_ETATS_INTERFACE.md](../../../10_ETATS_INTERFACE.md)
- Regles d'acces : [11_ETATS_CONDITIONNELS.md](../../../11_ETATS_CONDITIONNELS.md) · [17_REGLES_METIER.md](../../../17_REGLES_METIER.md)
- Captures a produire : [22_REGISTRE_CAPTURES.md](../../../22_REGISTRE_CAPTURES.md)

*Fiche generee le 2026-11-05 par `tools/extract.mjs` ; donnees brutes dans `evidence/pages.json`.
