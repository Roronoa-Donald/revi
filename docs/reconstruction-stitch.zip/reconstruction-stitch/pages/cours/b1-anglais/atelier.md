# Atelier d’analyse

> Fiche extraite du fichier `b1-anglais/atelier.html` (175 lignes, 10.3 Ko, sha256 `7ece1415e696`).
> Famille : **cours-b1-anglais** · sous-type : `atelier` · statut : **servi-canonique**.
> Cette fiche decrit ce que le document contient reellement ; les elements deduits du JavaScript sont signales `[deduit]` et references au document thematique.

## 1. Identite et acces

| Champ | Valeur |
|---|---|
| URL servie | `/b1-anglais/atelier.html` |
| Titre du document | Atelier d’analyse — simuler le business English \| Anglais des affaires B1 |
| Description meta | Atelier d’analyse du cours d'Anglais des affaires B1 : éditeur dans le navigateur, validation directe de la grille d’analyse, données du cas, console de sortie et tuteur qui explique les erreurs. |
| Robots | indexable (defaut) |
| Langue / theme | `fr` / `defaut` |
| Chapitre (body) | — |
| Regle d'acces | Compte connecte + niveau B1 ou superieur + abonnement actif |
| Statut de service | servi-canonique |

## 2. Structure du document (ordre observe)

| # | Element | Classe / role | Contenu cle |
|---|---|---|---|
| 1 | nav | skip-nav | 1 liens, aria="Accès rapide" |
| 2 | h1 | — | Atelier d’analyse |
| 3 | h2 | — | Zone libre |
| 4 | h2 | — | De la page au vrai message |
| 5 | h2 | — | Ensuite |
| 6 | .lab | code lab | 1 bloc(s) |

## 3. Hierarchie des titres

- **H1** — Atelier d’analyse
  - **H2** — Zone libre
    - **H3** — Zone libre — correcteur de registre
  - **H2** — De la page au vrai message
  - **H2** — Ensuite

## 4. Navigation et liens

| Zone | Classe | Liens |
|---|---|---|
| nav | `skip-nav` | Aller au contenu → `#content` |
| nav | `ennav` | Portail → `/`<br>Anglais des affaires B1 → `index.html`<br>Sommaire → `sommaire.html`<br>Ch. 1 → `chapitres/chapitre1.html`<br>Ch. 2 → `chapitres/chapitre2.html`<br>Ch. 3 → `chapitres/chapitre3.html`<br>Ch. 4 → `chapitres/chapitre4.html`<br>Ch. 5 → `chapitres/chapitre5.html`<br>Ch. 6 → `chapitres/chapitre6.html`<br>Cartes → `chapitres/cartes.html`<br>Mémo → `chapitres/formules.html`<br>Exercices → `exercices/exercices.html`<br>Atelier → `atelier.html`<br>Examen → `chapitres/simulateur-examen.html` |

Liens sortants : **19** (externes : 0).

| Libelle | href | Cible resolue | Type |
|---|---|---|---|
| Aller au contenu | `#content` | `#content` | ancre |
| Portail | `/` | `.` | interne |
| Anglais des affaires B1 | `index.html` | `b1-anglais/index.html` | interne |
| Sommaire | `sommaire.html` | `b1-anglais/sommaire.html` | interne |
| Ch. 1 | `chapitres/chapitre1.html` | `b1-anglais/chapitres/chapitre1.html` | interne |
| Ch. 2 | `chapitres/chapitre2.html` | `b1-anglais/chapitres/chapitre2.html` | interne |
| Ch. 3 | `chapitres/chapitre3.html` | `b1-anglais/chapitres/chapitre3.html` | interne |
| Ch. 4 | `chapitres/chapitre4.html` | `b1-anglais/chapitres/chapitre4.html` | interne |
| Ch. 5 | `chapitres/chapitre5.html` | `b1-anglais/chapitres/chapitre5.html` | interne |
| Ch. 6 | `chapitres/chapitre6.html` | `b1-anglais/chapitres/chapitre6.html` | interne |
| Cartes | `chapitres/cartes.html` | `b1-anglais/chapitres/cartes.html` | interne |
| Mémo | `chapitres/formules.html` | `b1-anglais/chapitres/formules.html` | interne |
| Exercices | `exercices/exercices.html` | `b1-anglais/exercices/exercices.html` | interne |
| Atelier | `atelier.html` | `b1-anglais/atelier.html` | interne |
| Examen | `chapitres/simulateur-examen.html` | `b1-anglais/chapitres/simulateur-examen.html` | interne |
| Chapitre 1 — Vocabulaire | `chapitres/chapitre1.html` | `b1-anglais/chapitres/chapitre1.html` | interne |

## 5. Formulaires et champs

Aucun formulaire dans cette page.
## 6. Boutons et controles interactifs

| Libelle | type | id | classes | aria-label | Etat initial | data-* |
|---|---|---|---|---|---|---|
| (icone) | button | themeToggle | `theme-toggle` | Activer le mode sombre | actif | — |

## 7. Composants pedagogiques et etats observes

| Exercice | Langage | Hauteur | Correction | Entree standard | Titre |
|---|---|---|---|---|---|
| `(zone libre)` | analyse | 360 | active | `(vide)` | Zone libre — correcteur de registre |

- Encadres pedagogiques : 3 (`.box`, variantes `box--*`).

Etats et interactions a reconstruire :

- Zone libre `data-lab` avec code de depart, entree standard pre-remplie, console, tuteur IA.
- Execution uniquement au clic (ou Ctrl+Entree) ; bouton Stop pendant l'execution.
- Etats de statut : pret, execution, succes, erreur, delai depasse, quota, service indisponible.
- Encadres explicatifs et trois erreurs classiques.

## 8. Tableaux, code et medias

- Tableaux : 0
- Blocs `pre` : 2 · elements `code` : 1
- SVG inline : 10 · images : 0
- Icones du sprite utilisees : `#i-house`, `#i-book`, `#i-target`, `#i-warning`, `#i-terminal`, `#i-arrow-left`, `#i-arrow-right`
- Volume de texte : ~697 mots · 134 noeuds HTML

## 9. Ressources chargees

- Feuilles de style : `https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600;700;800&display=swap`, `/assets/css/tokens.css`, `assets/css/cours.css`, `/assets/css/code-lab.css`, `/assets/vendor/katex/katex.min.css`
- Scripts externes : `/assets/js/theme.js`, `assets/js/cours.js`, `/assets/vendor/katex/katex.min.js`, `/assets/vendor/katex/auto-render.min.js`, `/assets/js/code-lab.js`
- Blocs `<style>` inline : 0 · scripts inline : 2

## 10. Classes et attributs data observes

Classes distinctes : 37. Les plus frequentes :

| Classe | Occurrences |
|---|---|
| `ic` | 8 |
| `box` | 3 |
| `box__title` | 3 |
| `lab__sample-part` | 2 |
| `btn` | 2 |
| `skip-nav` | 1 |
| `skip-link` | 1 |
| `ennav` | 1 |
| `ennav__in` | 1 |
| `ennav__home` | 1 |
| `ennav__sep` | 1 |
| `ennav__brand` | 1 |
| `ennav__links` | 1 |
| `is-active` | 1 |
| `ennav__actions` | 1 |
| `theme-toggle` | 1 |
| `theme-toggle__sun` | 1 |
| `theme-toggle__moon` | 1 |
| `enwrap` | 1 |
| `crumb` | 1 |

Attributs `data-*` : `data-lab` (1), `data-language` (1), `data-height` (1), `data-languages` (1), `data-stdin` (1), `data-lab-starter` (1)

## 11. Controle qualite automatique

- Titres `h1` : 1
- Boutons sans texte ni aria-label : 0
- Champs identifies sans label associe : 0
- Images sans attribut alt : 0
- Liens sans texte ni aria-label : 0
- Emoji detectes : 0 (la charte du produit les proscrit)

## 12. Renvois

- Layouts et gabarits : [04_LAYOUTS_ET_STRUCTURES.md](../../../04_LAYOUTS_ET_STRUCTURES.md)
- Composants et etats : [05_COMPOSANTS_REUTILISABLES.md](../../../05_COMPOSANTS_REUTILISABLES.md) · [10_ETATS_INTERFACE.md](../../../10_ETATS_INTERFACE.md)
- Regles d'acces : [11_ETATS_CONDITIONNELS.md](../../../11_ETATS_CONDITIONNELS.md) · [17_REGLES_METIER.md](../../../17_REGLES_METIER.md)
- Captures a produire : [22_REGISTRE_CAPTURES.md](../../../22_REGISTRE_CAPTURES.md)

*Fiche generee le 2026-11-05 par `tools/extract.mjs` ; donnees brutes dans `evidence/pages.json`.
