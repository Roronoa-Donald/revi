# Bureautique B1 — Word, Excel, PowerPoint

> Fiche extraite du fichier `b1-bureautique/index.html` (144 lignes, 11.1 Ko, sha256 `9d940b448b29`).
> Famille : **cours-b1-bureautique** · sous-type : `index` · statut : **servi-canonique**.
> Cette fiche decrit ce que le document contient reellement ; les elements deduits du JavaScript sont signales `[deduit]` et references au document thematique.

## 1. Identite et acces

| Champ | Valeur |
|---|---|
| URL servie | `/b1-bureautique/index.html` |
| Titre du document | Bureautique B1 — Word, Excel, PowerPoint \| Cours Interactif |
| Description meta | Cours complet de bureautique niveau B1 : Microsoft Word (ruban, modes d'affichage, mise en forme des caractères et des paragraphes, mise en page, impression), Excel (classeur et feuilles, barres de la fenêtre, formules et fonctions statistiques, conditionnelles SI, NB.SI, SOMME.SI, RANG, fonctions de texte) et PowerPoint (modes d'affichage, modèles, thèmes, diaporama et minutage). Chaque règle est scriptée en Bash et réellement exécutée dans la page. |
| Robots | indexable (defaut) |
| Langue / theme | `fr` / `defaut` |
| Chapitre (body) | — |
| Regle d'acces | Libre (aucun compte) |
| Statut de service | servi-canonique |

## 2. Structure du document (ordre observe)

| # | Element | Classe / role | Contenu cle |
|---|---|---|---|
| 1 | nav | skip-nav | 1 liens, aria="Accès rapide" |
| 2 | h1 | — | Bureautique B1 — Word, Excel, PowerPoint |
| 3 | h2 | — | Programme du cours |

## 3. Hierarchie des titres

- **H1** — Bureautique B1 — Word, Excel, PowerPoint
  - **H2** — Programme du cours

## 4. Navigation et liens

| Zone | Classe | Liens |
|---|---|---|
| nav | `skip-nav` | Aller au contenu → `#content` |
| nav | `bunav` | Portail → `/`<br>Bureautique B1 → `index.html`<br>Sommaire → `sommaire.html`<br>Ch. 1 → `chapitres/chapitre1.html`<br>Ch. 2 → `chapitres/chapitre2.html`<br>Ch. 3 → `chapitres/chapitre3.html`<br>Ch. 4 → `chapitres/chapitre4.html`<br>Ch. 5 → `chapitres/chapitre5.html`<br>Ch. 6 → `chapitres/chapitre6.html`<br>Cartes → `chapitres/cartes.html`<br>Mémo → `chapitres/formules.html`<br>Exercices → `exercices/exercices.html`<br>Atelier → `atelier.html`<br>Examen → `chapitres/simulateur-examen.html` |

Liens sortants : **28** (externes : 0).

| Libelle | href | Cible resolue | Type |
|---|---|---|---|
| Aller au contenu | `#content` | `#content` | ancre |
| Portail | `/` | `.` | interne |
| Bureautique B1 | `index.html` | `b1-bureautique/index.html` | interne |
| Sommaire | `sommaire.html` | `b1-bureautique/sommaire.html` | interne |
| Ch. 1 | `chapitres/chapitre1.html` | `b1-bureautique/chapitres/chapitre1.html` | interne |
| Ch. 2 | `chapitres/chapitre2.html` | `b1-bureautique/chapitres/chapitre2.html` | interne |
| Ch. 3 | `chapitres/chapitre3.html` | `b1-bureautique/chapitres/chapitre3.html` | interne |
| Ch. 4 | `chapitres/chapitre4.html` | `b1-bureautique/chapitres/chapitre4.html` | interne |
| Ch. 5 | `chapitres/chapitre5.html` | `b1-bureautique/chapitres/chapitre5.html` | interne |
| Ch. 6 | `chapitres/chapitre6.html` | `b1-bureautique/chapitres/chapitre6.html` | interne |
| Cartes | `chapitres/cartes.html` | `b1-bureautique/chapitres/cartes.html` | interne |
| Mémo | `chapitres/formules.html` | `b1-bureautique/chapitres/formules.html` | interne |
| Exercices | `exercices/exercices.html` | `b1-bureautique/exercices/exercices.html` | interne |
| Atelier | `atelier.html` | `b1-bureautique/atelier.html` | interne |
| Examen | `chapitres/simulateur-examen.html` | `b1-bureautique/chapitres/simulateur-examen.html` | interne |
| Portail des cours | `/index.html` | `index.html` | interne |
| 1 Word : l'interface et la saisie Le ruban et ses onglets ; les cinq modes d'affichage ; la barre d'état et le comptage | `chapitres/chapitre1.html` | `b1-bureautique/chapitres/chapitre1.html` | interne |
| 2 Word : mise en forme et mise en page Groupe Police et Paragraphe ; les quatre alignements ; interligne, retraits et ta | `chapitres/chapitre2.html` | `b1-bureautique/chapitres/chapitre2.html` | interne |
| 3 Excel : la feuille de calcul Classeur et feuilles ; les barres de la fenêtre et les sept onglets ; saisir des données | `chapitres/chapitre3.html` | `b1-bureautique/chapitres/chapitre3.html` | interne |
| 4 Excel : formules et fonctions statistiques La formule commence par = ; les quatre familles d'opérateurs ; SOMME, MOYEN | `chapitres/chapitre4.html` | `b1-bureautique/chapitres/chapitre4.html` | interne |
| 5 Excel : conditionnelles et compteurs conditionnels La fonction SI et le SI imbriqué (commission, mentions) ; NB.SI, SO | `chapitres/chapitre5.html` | `b1-bureautique/chapitres/chapitre5.html` | interne |
| 6 PowerPoint : la présentation Les quatre modes d'affichage ; créer une présentation (vierge ou modèle) ; thèmes et coul | `chapitres/chapitre6.html` | `b1-bureautique/chapitres/chapitre6.html` | interne |
| Commencer le chapitre 1 | `chapitres/chapitre1.html` | `b1-bureautique/chapitres/chapitre1.html` | interne |
| Flashcards | `chapitres/cartes.html` | `b1-bureautique/chapitres/cartes.html` | interne |
| … | | | 4 lien(s) supplementaire(s) |

## 5. Formulaires et champs

Aucun formulaire dans cette page.
## 6. Boutons et controles interactifs

| Libelle | type | id | classes | aria-label | Etat initial | data-* |
|---|---|---|---|---|---|---|
| (icone) | button | themeToggle | `theme-toggle` | Activer le mode sombre | actif | — |

## 7. Composants pedagogiques et etats observes

- Encadres pedagogiques : 3 (`.box`, variantes `box--*`).

Etats et interactions a reconstruire :

- En-tête : marque + 3 liens (Epreuves, Atelier, Mon compte) + bouton profil + bascule de thème.
- Etat `prepLockedMsg` : bandeau « L'atelier est protege » si `?preparation=locked`, refermable.
- Filtre de niveau : 4 onglets (B1/B2/B3/Tous), onglet actif noir, persistance `portal_selected_level`.
- Recherche : champ `#courseSearch`, filtrage en direct sur `data-title` ; compteur `#activeFilterCount`.
- Etat vide : `#portalEmptyState` (bloc pointille) avec bouton de reinitialisation des filtres.
- Carte « Reprendre » : masquee par defaut (`hidden`), visible si progression locale > 0.
- Utilisateur connecte : bouton profil marque `is-authenticated`, nom en title/aria-label.

## 8. Tableaux, code et medias

- Tableaux : 0
- Blocs `pre` : 0 · elements `code` : 0
- SVG inline : 13 · images : 0
- Icones du sprite utilisees : `#i-house`, `#i-chart`, `#i-target`, `#i-compass`, `#i-wrench`, `#i-rocket`, `#i-cards`, `#i-file`, `#i-terminal`, `#i-blocks`, `#i-clipboard`
- Volume de texte : ~630 mots · 148 noeuds HTML

## 9. Ressources chargees

- Feuilles de style : `https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600;700;800&display=swap`, `/assets/css/tokens.css`, `assets/css/cours.css`, `/assets/css/code-lab.css`, `/assets/vendor/katex/katex.min.css`
- Scripts externes : `/assets/js/theme.js`, `assets/js/cours.js`, `/assets/vendor/katex/katex.min.js`, `/assets/vendor/katex/auto-render.min.js`, `/assets/js/code-lab.js`
- Blocs `<style>` inline : 0 · scripts inline : 1

## 10. Classes et attributs data observes

Classes distinctes : 31. Les plus frequentes :

| Classe | Occurrences |
|---|---|
| `ic` | 11 |
| `toc__item` | 6 |
| `toc__n` | 6 |
| `toc__t` | 6 |
| `toc__d` | 6 |
| `btn` | 6 |
| `tag` | 3 |
| `box` | 3 |
| `box__title` | 3 |
| `tag--time` | 2 |
| `skip-nav` | 1 |
| `skip-link` | 1 |
| `bunav` | 1 |
| `bunav__in` | 1 |
| `bunav__home` | 1 |
| `bunav__sep` | 1 |
| `bunav__brand` | 1 |
| `bunav__links` | 1 |
| `bunav__actions` | 1 |
| `theme-toggle` | 1 |

Aucun attribut `data-*`.

## 11. Controle qualite automatique

- Titres `h1` : 1
- Boutons sans texte ni aria-label : 0
- Champs identifies sans label associe : 0
- Images sans attribut alt : 0
- Liens sans texte ni aria-label : 0
- Emoji detectes : 0 (la charte du produit les proscrit)

## 12. Renvois

- Layouts et gabarits : [04_LAYOUTS_ET_STRUCTURES.md](../../../04_LAYOUTS_ET_STRUCTURES.md)
- Composants et etats : [05_COMPOSANTS_REUTILISABLES.md](../../../05_COMPOSANTS_REUTILISABLES.md) · [10_ETATS_INTERFACE.md](../../../10_ETATS_INTERFACE.md)
- Regles d'acces : [11_ETATS_CONDITIONNELS.md](../../../11_ETATS_CONDITIONNELS.md) · [17_REGLES_METIER.md](../../../17_REGLES_METIER.md)
- Captures a produire : [22_REGISTRE_CAPTURES.md](../../../22_REGISTRE_CAPTURES.md)

*Fiche generee le 2026-11-05 par `tools/extract.mjs` ; donnees brutes dans `evidence/pages.json`.
