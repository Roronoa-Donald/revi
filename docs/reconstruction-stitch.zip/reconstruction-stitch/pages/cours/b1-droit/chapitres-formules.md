# Mémo droit

> Fiche extraite du fichier `b1-droit/chapitres/formules.html` (213 lignes, 8.6 Ko, sha256 `8ba909372a19`).
> Famille : **cours-b1-droit** · sous-type : `formules` · statut : **servi-canonique**.
> Cette fiche decrit ce que le document contient reellement ; les elements deduits du JavaScript sont signales `[deduit]` et references au document thematique.

## 1. Identite et acces

| Champ | Valeur |
|---|---|
| URL servie | `/b1-droit/chapitres/formules.html` |
| Titre du document | Mémo droit — Droit B1 |
| Description meta | Mémo du cours de Droit B1 : règle de droit, sanctions, sources, pyramide des normes, personnalité juridique, loi dans le temps, juridictions et contrat sur une page. |
| Robots | indexable (defaut) |
| Langue / theme | `fr` / `defaut` |
| Chapitre (body) | — |
| Regle d'acces | Compte connecte + niveau B1 ou superieur + abonnement actif |
| Statut de service | servi-canonique |

## 2. Structure du document (ordre observe)

| # | Element | Classe / role | Contenu cle |
|---|---|---|---|
| 1 | nav | skip-nav | 1 liens, aria="Accès rapide" |
| 2 | h1 | — | Mémo droit |
| 3 | h2 | — | Qualifier : objectif, subjectif, règle |
| 4 | h2 | — | Sources et pyramide des normes |
| 5 | h2 | — | La loi dans le temps |
| 6 | h2 | — | Personnalité juridique |
| 7 | h2 | — | Justice : principes et juridictions |
| 8 | h2 | — | Contrat et responsabilité |
| 9 | h2 | — | Erreurs fréquentes à éviter |

## 3. Hierarchie des titres

- **H1** — Mémo droit
  - **H2** — Qualifier : objectif, subjectif, règle
  - **H2** — Sources et pyramide des normes
  - **H2** — La loi dans le temps
  - **H2** — Personnalité juridique
  - **H2** — Justice : principes et juridictions
  - **H2** — Contrat et responsabilité
  - **H2** — Erreurs fréquentes à éviter

## 4. Navigation et liens

| Zone | Classe | Liens |
|---|---|---|
| nav | `skip-nav` | Aller au contenu → `#content` |
| nav | `drnav` | Portail → `/`<br>Droit B1 → `../index.html`<br>Sommaire → `../sommaire.html`<br>Ch. 1 → `../chapitres/chapitre1.html`<br>Ch. 2 → `../chapitres/chapitre2.html`<br>Ch. 3 → `../chapitres/chapitre3.html`<br>Ch. 4 → `../chapitres/chapitre4.html`<br>Ch. 5 → `../chapitres/chapitre5.html`<br>Ch. 6 → `../chapitres/chapitre6.html`<br>Cartes → `../chapitres/cartes.html`<br>Mémo → `../chapitres/formules.html`<br>Exercices → `../exercices/exercices.html`<br>Atelier → `../atelier.html`<br>Examen → `../chapitres/simulateur-examen.html` |

Liens sortants : **19** (externes : 0).

| Libelle | href | Cible resolue | Type |
|---|---|---|---|
| Aller au contenu | `#content` | `#content` | ancre |
| Portail | `/` | `.` | interne |
| Droit B1 | `../index.html` | `b1-droit/index.html` | interne |
| Sommaire | `../sommaire.html` | `b1-droit/sommaire.html` | interne |
| Ch. 1 | `../chapitres/chapitre1.html` | `b1-droit/chapitres/chapitre1.html` | interne |
| Ch. 2 | `../chapitres/chapitre2.html` | `b1-droit/chapitres/chapitre2.html` | interne |
| Ch. 3 | `../chapitres/chapitre3.html` | `b1-droit/chapitres/chapitre3.html` | interne |
| Ch. 4 | `../chapitres/chapitre4.html` | `b1-droit/chapitres/chapitre4.html` | interne |
| Ch. 5 | `../chapitres/chapitre5.html` | `b1-droit/chapitres/chapitre5.html` | interne |
| Ch. 6 | `../chapitres/chapitre6.html` | `b1-droit/chapitres/chapitre6.html` | interne |
| Cartes | `../chapitres/cartes.html` | `b1-droit/chapitres/cartes.html` | interne |
| Mémo | `../chapitres/formules.html` | `b1-droit/chapitres/formules.html` | interne |
| Exercices | `../exercices/exercices.html` | `b1-droit/exercices/exercices.html` | interne |
| Atelier | `../atelier.html` | `b1-droit/atelier.html` | interne |
| Examen | `../chapitres/simulateur-examen.html` | `b1-droit/chapitres/simulateur-examen.html` | interne |
| Cartes | `cartes.html` | `b1-droit/chapitres/cartes.html` | interne |
| Examens blancs | `simulateur-examen.html` | `b1-droit/chapitres/simulateur-examen.html` | interne |

## 5. Formulaires et champs

Aucun formulaire dans cette page.
## 6. Boutons et controles interactifs

| Libelle | type | id | classes | aria-label | Etat initial | data-* |
|---|---|---|---|---|---|---|
| (icone) | button | themeToggle | `theme-toggle` | Activer le mode sombre | actif | — |

## 7. Composants pedagogiques et etats observes


Etats et interactions a reconstruire :

- Page memo : tableaux de correspondance pseudo-code / Pascal / Python, blocs de code.
- Aucun etat dynamique propre (lecture seule).

## 8. Tableaux, code et medias

- Tableaux : 0
- Blocs `pre` : 6 · elements `code` : 6
- SVG inline : 6 · images : 0
- Icones du sprite utilisees : `#i-house`, `#i-scale`, `#i-arrow-left`, `#i-arrow-right`
- Volume de texte : ~602 mots · 105 noeuds HTML

## 9. Ressources chargees

- Feuilles de style : `https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600;700;800&display=swap`, `/assets/css/tokens.css`, `../assets/css/cours.css`, `/assets/css/code-lab.css`, `/assets/vendor/katex/katex.min.css`
- Scripts externes : `/assets/js/theme.js`, `../assets/js/cours.js`, `/assets/vendor/katex/katex.min.js`, `/assets/vendor/katex/auto-render.min.js`, `/assets/js/code-lab.js`
- Blocs `<style>` inline : 0 · scripts inline : 1

## 10. Classes et attributs data observes

Classes distinctes : 20. Les plus frequentes :

| Classe | Occurrences |
|---|---|
| `ic` | 4 |
| `btn` | 2 |
| `skip-nav` | 1 |
| `skip-link` | 1 |
| `drnav` | 1 |
| `drnav__in` | 1 |
| `drnav__home` | 1 |
| `drnav__sep` | 1 |
| `drnav__brand` | 1 |
| `drnav__links` | 1 |
| `is-active` | 1 |
| `drnav__actions` | 1 |
| `theme-toggle` | 1 |
| `theme-toggle__sun` | 1 |
| `theme-toggle__moon` | 1 |
| `drwrap` | 1 |
| `crumb` | 1 |
| `lead` | 1 |
| `chnav` | 1 |
| `btn--primary` | 1 |

Aucun attribut `data-*`.

## 11. Controle qualite automatique

- Titres `h1` : 1
- Boutons sans texte ni aria-label : 0
- Champs identifies sans label associe : 0
- Images sans attribut alt : 0
- Liens sans texte ni aria-label : 0
- Emoji detectes : 0 (la charte du produit les proscrit)

## 12. Renvois

- Layouts et gabarits : [04_LAYOUTS_ET_STRUCTURES.md](../../../04_LAYOUTS_ET_STRUCTURES.md)
- Composants et etats : [05_COMPOSANTS_REUTILISABLES.md](../../../05_COMPOSANTS_REUTILISABLES.md) · [10_ETATS_INTERFACE.md](../../../10_ETATS_INTERFACE.md)
- Regles d'acces : [11_ETATS_CONDITIONNELS.md](../../../11_ETATS_CONDITIONNELS.md) · [17_REGLES_METIER.md](../../../17_REGLES_METIER.md)
- Captures a produire : [22_REGISTRE_CAPTURES.md](../../../22_REGISTRE_CAPTURES.md)

*Fiche generee le 2026-11-05 par `tools/extract.mjs` ; donnees brutes dans `evidence/pages.json`.
