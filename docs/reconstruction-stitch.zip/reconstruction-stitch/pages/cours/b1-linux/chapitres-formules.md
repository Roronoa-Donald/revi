# Mémo de l’administrateur

> Fiche extraite du fichier `b1-linux/chapitres/formules.html` (192 lignes, 8.7 Ko, sha256 `7ec1e743b25a`).
> Famille : **cours-b1-linux** · sous-type : `formules` · statut : **servi-canonique**.
> Cette fiche decrit ce que le document contient reellement ; les elements deduits du JavaScript sont signales `[deduit]` et references au document thematique.

## 1. Identite et acces

| Champ | Valeur |
|---|---|
| URL servie | `/b1-linux/chapitres/formules.html` |
| Titre du document | Mémo de l’administrateur — Linux B1 |
| Description meta | Mémo du cours de Linux B1 : arborescence, commandes de base, find, comptes et groupes, droits d’accès et squelette de script Bash sur une page. |
| Robots | indexable (defaut) |
| Langue / theme | `fr` / `defaut` |
| Chapitre (body) | — |
| Regle d'acces | Compte connecte + niveau B1 ou superieur + abonnement actif |
| Statut de service | servi-canonique |

## 2. Structure du document (ordre observe)

| # | Element | Classe / role | Contenu cle |
|---|---|---|---|
| 1 | nav | skip-nav | 1 liens, aria="Accès rapide" |
| 2 | h1 | — | Mémo de l’administrateur |
| 3 | h2 | — | L’arborescence en une image |
| 4 | h2 | — | Commandes de base |
| 5 | h2 | — | find : chercher |
| 6 | h2 | — | Comptes et groupes |
| 7 | h2 | — | Droits d’accès |
| 8 | h2 | — | Squelette d’un script Bash |
| 9 | h2 | — | Erreurs fréquentes à éviter |

## 3. Hierarchie des titres

- **H1** — Mémo de l’administrateur
  - **H2** — L’arborescence en une image
  - **H2** — Commandes de base
  - **H2** — find : chercher
  - **H2** — Comptes et groupes
  - **H2** — Droits d’accès
  - **H2** — Squelette d’un script Bash
  - **H2** — Erreurs fréquentes à éviter

## 4. Navigation et liens

| Zone | Classe | Liens |
|---|---|---|
| nav | `skip-nav` | Aller au contenu → `#content` |
| nav | `lxnav` | Portail → `/`<br>Linux B1 → `../index.html`<br>Sommaire → `../sommaire.html`<br>Ch. 1 → `../chapitres/chapitre1.html`<br>Ch. 2 → `../chapitres/chapitre2.html`<br>Ch. 3 → `../chapitres/chapitre3.html`<br>Ch. 4 → `../chapitres/chapitre4.html`<br>Ch. 5 → `../chapitres/chapitre5.html`<br>Ch. 6 → `../chapitres/chapitre6.html`<br>Cartes → `../chapitres/cartes.html`<br>Mémo → `../chapitres/formules.html`<br>Exercices → `../exercices/exercices.html`<br>Atelier → `../atelier.html`<br>Examen → `../chapitres/simulateur-examen.html` |

Liens sortants : **19** (externes : 0).

| Libelle | href | Cible resolue | Type |
|---|---|---|---|
| Aller au contenu | `#content` | `#content` | ancre |
| Portail | `/` | `.` | interne |
| Linux B1 | `../index.html` | `b1-linux/index.html` | interne |
| Sommaire | `../sommaire.html` | `b1-linux/sommaire.html` | interne |
| Ch. 1 | `../chapitres/chapitre1.html` | `b1-linux/chapitres/chapitre1.html` | interne |
| Ch. 2 | `../chapitres/chapitre2.html` | `b1-linux/chapitres/chapitre2.html` | interne |
| Ch. 3 | `../chapitres/chapitre3.html` | `b1-linux/chapitres/chapitre3.html` | interne |
| Ch. 4 | `../chapitres/chapitre4.html` | `b1-linux/chapitres/chapitre4.html` | interne |
| Ch. 5 | `../chapitres/chapitre5.html` | `b1-linux/chapitres/chapitre5.html` | interne |
| Ch. 6 | `../chapitres/chapitre6.html` | `b1-linux/chapitres/chapitre6.html` | interne |
| Cartes | `../chapitres/cartes.html` | `b1-linux/chapitres/cartes.html` | interne |
| Mémo | `../chapitres/formules.html` | `b1-linux/chapitres/formules.html` | interne |
| Exercices | `../exercices/exercices.html` | `b1-linux/exercices/exercices.html` | interne |
| Atelier | `../atelier.html` | `b1-linux/atelier.html` | interne |
| Examen | `../chapitres/simulateur-examen.html` | `b1-linux/chapitres/simulateur-examen.html` | interne |
| Cartes | `cartes.html` | `b1-linux/chapitres/cartes.html` | interne |
| Examens blancs | `simulateur-examen.html` | `b1-linux/chapitres/simulateur-examen.html` | interne |

## 5. Formulaires et champs

Aucun formulaire dans cette page.
## 6. Boutons et controles interactifs

| Libelle | type | id | classes | aria-label | Etat initial | data-* |
|---|---|---|---|---|---|---|
| (icone) | button | themeToggle | `theme-toggle` | Activer le mode sombre | actif | — |

## 7. Composants pedagogiques et etats observes


Etats et interactions a reconstruire :

- Page memo : tableaux de correspondance pseudo-code / Pascal / Python, blocs de code.
- Aucun etat dynamique propre (lecture seule).

## 8. Tableaux, code et medias

- Tableaux : 0
- Blocs `pre` : 6 · elements `code` : 6
- SVG inline : 6 · images : 0
- Icones du sprite utilisees : `#i-house`, `#i-terminal`, `#i-arrow-left`, `#i-arrow-right`
- Volume de texte : ~587 mots · 103 noeuds HTML

## 9. Ressources chargees

- Feuilles de style : `https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600;700;800&display=swap`, `/assets/css/tokens.css`, `../assets/css/cours.css`, `/assets/css/code-lab.css`, `/assets/vendor/katex/katex.min.css`
- Scripts externes : `/assets/js/theme.js`, `../assets/js/cours.js`, `/assets/vendor/katex/katex.min.js`, `/assets/vendor/katex/auto-render.min.js`, `/assets/js/code-lab.js`
- Blocs `<style>` inline : 0 · scripts inline : 1

## 10. Classes et attributs data observes

Classes distinctes : 20. Les plus frequentes :

| Classe | Occurrences |
|---|---|
| `ic` | 4 |
| `btn` | 2 |
| `skip-nav` | 1 |
| `skip-link` | 1 |
| `lxnav` | 1 |
| `lxnav__in` | 1 |
| `lxnav__home` | 1 |
| `lxnav__sep` | 1 |
| `lxnav__brand` | 1 |
| `lxnav__links` | 1 |
| `is-active` | 1 |
| `lxnav__actions` | 1 |
| `theme-toggle` | 1 |
| `theme-toggle__sun` | 1 |
| `theme-toggle__moon` | 1 |
| `lxwrap` | 1 |
| `crumb` | 1 |
| `lead` | 1 |
| `chnav` | 1 |
| `btn--primary` | 1 |

Aucun attribut `data-*`.

## 11. Controle qualite automatique

- Titres `h1` : 1
- Boutons sans texte ni aria-label : 0
- Champs identifies sans label associe : 0
- Images sans attribut alt : 0
- Liens sans texte ni aria-label : 0
- Emoji detectes : 0 (la charte du produit les proscrit)

## 12. Renvois

- Layouts et gabarits : [04_LAYOUTS_ET_STRUCTURES.md](../../../04_LAYOUTS_ET_STRUCTURES.md)
- Composants et etats : [05_COMPOSANTS_REUTILISABLES.md](../../../05_COMPOSANTS_REUTILISABLES.md) · [10_ETATS_INTERFACE.md](../../../10_ETATS_INTERFACE.md)
- Regles d'acces : [11_ETATS_CONDITIONNELS.md](../../../11_ETATS_CONDITIONNELS.md) · [17_REGLES_METIER.md](../../../17_REGLES_METIER.md)
- Captures a produire : [22_REGISTRE_CAPTURES.md](../../../22_REGISTRE_CAPTURES.md)

*Fiche generee le 2026-11-05 par `tools/extract.mjs` ; donnees brutes dans `evidence/pages.json`.
