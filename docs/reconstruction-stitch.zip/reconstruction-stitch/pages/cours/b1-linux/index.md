# Linux B1 — arborescence, droits, comptes et scripts

> Fiche extraite du fichier `b1-linux/index.html` (144 lignes, 10.4 Ko, sha256 `f9f58592115b`).
> Famille : **cours-b1-linux** · sous-type : `index` · statut : **servi-canonique**.
> Cette fiche decrit ce que le document contient reellement ; les elements deduits du JavaScript sont signales `[deduit]` et references au document thematique.

## 1. Identite et acces

| Champ | Valeur |
|---|---|
| URL servie | `/b1-linux/index.html` |
| Titre du document | Linux B1 — arborescence, droits, comptes et scripts \| Cours Interactif |
| Description meta | Cours complet de système Linux niveau B1 : histoire et architecture de GNU/Linux, arborescence et systèmes de fichiers, installation de Debian 12, commandes de base du terminal, comptes utilisateurs et groupes, droits d’accès et scripts shell. Chaque mécanisme du système est scripté en Bash et réellement exécuté dans la page. |
| Robots | indexable (defaut) |
| Langue / theme | `fr` / `defaut` |
| Chapitre (body) | — |
| Regle d'acces | Libre (aucun compte) |
| Statut de service | servi-canonique |

## 2. Structure du document (ordre observe)

| # | Element | Classe / role | Contenu cle |
|---|---|---|---|
| 1 | nav | skip-nav | 1 liens, aria="Accès rapide" |
| 2 | h1 | — | Linux B1 — arborescence, droits, comptes et scripts |
| 3 | h2 | — | Programme du cours |

## 3. Hierarchie des titres

- **H1** — Linux B1 — arborescence, droits, comptes et scripts
  - **H2** — Programme du cours

## 4. Navigation et liens

| Zone | Classe | Liens |
|---|---|---|
| nav | `skip-nav` | Aller au contenu → `#content` |
| nav | `lxnav` | Portail → `/`<br>Linux B1 → `index.html`<br>Sommaire → `sommaire.html`<br>Ch. 1 → `chapitres/chapitre1.html`<br>Ch. 2 → `chapitres/chapitre2.html`<br>Ch. 3 → `chapitres/chapitre3.html`<br>Ch. 4 → `chapitres/chapitre4.html`<br>Ch. 5 → `chapitres/chapitre5.html`<br>Ch. 6 → `chapitres/chapitre6.html`<br>Cartes → `chapitres/cartes.html`<br>Mémo → `chapitres/formules.html`<br>Exercices → `exercices/exercices.html`<br>Atelier → `atelier.html`<br>Examen → `chapitres/simulateur-examen.html` |

Liens sortants : **28** (externes : 0).

| Libelle | href | Cible resolue | Type |
|---|---|---|---|
| Aller au contenu | `#content` | `#content` | ancre |
| Portail | `/` | `.` | interne |
| Linux B1 | `index.html` | `b1-linux/index.html` | interne |
| Sommaire | `sommaire.html` | `b1-linux/sommaire.html` | interne |
| Ch. 1 | `chapitres/chapitre1.html` | `b1-linux/chapitres/chapitre1.html` | interne |
| Ch. 2 | `chapitres/chapitre2.html` | `b1-linux/chapitres/chapitre2.html` | interne |
| Ch. 3 | `chapitres/chapitre3.html` | `b1-linux/chapitres/chapitre3.html` | interne |
| Ch. 4 | `chapitres/chapitre4.html` | `b1-linux/chapitres/chapitre4.html` | interne |
| Ch. 5 | `chapitres/chapitre5.html` | `b1-linux/chapitres/chapitre5.html` | interne |
| Ch. 6 | `chapitres/chapitre6.html` | `b1-linux/chapitres/chapitre6.html` | interne |
| Cartes | `chapitres/cartes.html` | `b1-linux/chapitres/cartes.html` | interne |
| Mémo | `chapitres/formules.html` | `b1-linux/chapitres/formules.html` | interne |
| Exercices | `exercices/exercices.html` | `b1-linux/exercices/exercices.html` | interne |
| Atelier | `atelier.html` | `b1-linux/atelier.html` | interne |
| Examen | `chapitres/simulateur-examen.html` | `b1-linux/chapitres/simulateur-examen.html` | interne |
| Portail des cours | `/index.html` | `index.html` | interne |
| 1 Le système GNU/Linux : histoire, licence, architecture D’UNIX à Linux, les quatre libertés du logiciel libre, distribu | `chapitres/chapitre1.html` | `b1-linux/chapitres/chapitre1.html` | interne |
| 2 Arborescence et système de fichiers La racine et les répertoires standard, tout est fichier, systèmes de fichiers, par | `chapitres/chapitre2.html` | `b1-linux/chapitres/chapitre2.html` | interne |
| 3 Commandes de base : trouver, manipuler, chercher Syntaxe d’une commande, navigation et manipulation de fichiers, liens | `chapitres/chapitre3.html` | `b1-linux/chapitres/chapitre3.html` | interne |
| 4 Installer Debian 12 Choisir une image et un support d’installation, partitionner le disque, configurer les dépôts et l | `chapitres/chapitre4.html` | `b1-linux/chapitres/chapitre4.html` | interne |
| 5 Utilisateurs, groupes et fichiers de comptes Le format /etc/passwd, /etc/shadow et /etc/group, créer et modifier des c | `chapitres/chapitre5.html` | `b1-linux/chapitres/chapitre5.html` | interne |
| 6 Droits d’accès et scripts shell (TP) Lire rwxr-xr-x, calculer et modifier les droits (chmod, chown, chgrp), écrire ses | `chapitres/chapitre6.html` | `b1-linux/chapitres/chapitre6.html` | interne |
| Commencer le chapitre 1 | `chapitres/chapitre1.html` | `b1-linux/chapitres/chapitre1.html` | interne |
| Flashcards | `chapitres/cartes.html` | `b1-linux/chapitres/cartes.html` | interne |
| … | | | 4 lien(s) supplementaire(s) |

## 5. Formulaires et champs

Aucun formulaire dans cette page.
## 6. Boutons et controles interactifs

| Libelle | type | id | classes | aria-label | Etat initial | data-* |
|---|---|---|---|---|---|---|
| (icone) | button | themeToggle | `theme-toggle` | Activer le mode sombre | actif | — |

## 7. Composants pedagogiques et etats observes

- Encadres pedagogiques : 3 (`.box`, variantes `box--*`).

Etats et interactions a reconstruire :

- En-tête : marque + 3 liens (Epreuves, Atelier, Mon compte) + bouton profil + bascule de thème.
- Etat `prepLockedMsg` : bandeau « L'atelier est protege » si `?preparation=locked`, refermable.
- Filtre de niveau : 4 onglets (B1/B2/B3/Tous), onglet actif noir, persistance `portal_selected_level`.
- Recherche : champ `#courseSearch`, filtrage en direct sur `data-title` ; compteur `#activeFilterCount`.
- Etat vide : `#portalEmptyState` (bloc pointille) avec bouton de reinitialisation des filtres.
- Carte « Reprendre » : masquee par defaut (`hidden`), visible si progression locale > 0.
- Utilisateur connecte : bouton profil marque `is-authenticated`, nom en title/aria-label.

## 8. Tableaux, code et medias

- Tableaux : 0
- Blocs `pre` : 0 · elements `code` : 0
- SVG inline : 13 · images : 0
- Icones du sprite utilisees : `#i-house`, `#i-terminal`, `#i-target`, `#i-compass`, `#i-wrench`, `#i-rocket`, `#i-cards`, `#i-file`, `#i-blocks`, `#i-clipboard`
- Volume de texte : ~545 mots · 148 noeuds HTML

## 9. Ressources chargees

- Feuilles de style : `https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600;700;800&display=swap`, `/assets/css/tokens.css`, `assets/css/cours.css`, `/assets/css/code-lab.css`, `/assets/vendor/katex/katex.min.css`
- Scripts externes : `/assets/js/theme.js`, `assets/js/cours.js`, `/assets/vendor/katex/katex.min.js`, `/assets/vendor/katex/auto-render.min.js`, `/assets/js/code-lab.js`
- Blocs `<style>` inline : 0 · scripts inline : 1

## 10. Classes et attributs data observes

Classes distinctes : 31. Les plus frequentes :

| Classe | Occurrences |
|---|---|
| `ic` | 11 |
| `toc__item` | 6 |
| `toc__n` | 6 |
| `toc__t` | 6 |
| `toc__d` | 6 |
| `btn` | 6 |
| `tag` | 3 |
| `box` | 3 |
| `box__title` | 3 |
| `tag--time` | 2 |
| `skip-nav` | 1 |
| `skip-link` | 1 |
| `lxnav` | 1 |
| `lxnav__in` | 1 |
| `lxnav__home` | 1 |
| `lxnav__sep` | 1 |
| `lxnav__brand` | 1 |
| `lxnav__links` | 1 |
| `lxnav__actions` | 1 |
| `theme-toggle` | 1 |

Aucun attribut `data-*`.

## 11. Controle qualite automatique

- Titres `h1` : 1
- Boutons sans texte ni aria-label : 0
- Champs identifies sans label associe : 0
- Images sans attribut alt : 0
- Liens sans texte ni aria-label : 0
- Emoji detectes : 0 (la charte du produit les proscrit)

## 12. Renvois

- Layouts et gabarits : [04_LAYOUTS_ET_STRUCTURES.md](../../../04_LAYOUTS_ET_STRUCTURES.md)
- Composants et etats : [05_COMPOSANTS_REUTILISABLES.md](../../../05_COMPOSANTS_REUTILISABLES.md) · [10_ETATS_INTERFACE.md](../../../10_ETATS_INTERFACE.md)
- Regles d'acces : [11_ETATS_CONDITIONNELS.md](../../../11_ETATS_CONDITIONNELS.md) · [17_REGLES_METIER.md](../../../17_REGLES_METIER.md)
- Captures a produire : [22_REGISTRE_CAPTURES.md](../../../22_REGISTRE_CAPTURES.md)

*Fiche generee le 2026-11-05 par `tools/extract.mjs` ; donnees brutes dans `evidence/pages.json`.
