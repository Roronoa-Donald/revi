# Superpowers Brainstorming

> Fiche extraite du fichier `agent/skills/brainstorming/scripts/frame-template.html` (214 lignes, 7.9 Ko, sha256 `6a8a4e58bd6a`).
> Famille : **hors-produit** · sous-type : `agent` · statut : **servi-local-render-seulement**.
> Cette fiche decrit ce que le document contient reellement ; les elements deduits du JavaScript sont signales `[deduit]` et references au document thematique.

## 1. Identite et acces

| Champ | Valeur |
|---|---|
| URL servie | `/agent/skills/brainstorming/scripts/frame-template.html (local/Render uniquement, absent du build dist)` |
| Titre du document | Superpowers Brainstorming |
| Description meta | — |
| Robots | indexable (defaut) |
| Langue / theme | `—` / `defaut` |
| Chapitre (body) | — |
| Regle d'acces | Hors produit / archive |
| Statut de service | servi-local-render-seulement |

## 2. Structure du document (ordre observe)

| # | Element | Classe / role | Contenu cle |
|---|---|---|---|
| 1 | main | — | Page sans navigation ni composant structurel majeur |

## 3. Hierarchie des titres

- Aucun titre (`h1`–`h4`) dans le document.

## 4. Navigation et liens

Liens sortants : **0** (externes : 0).

## 5. Formulaires et champs

Aucun formulaire dans cette page.
## 6. Boutons et controles interactifs

Aucun `<button>` dans le document (les actions peuvent etre des liens stylises).

## 7. Composants pedagogiques et etats observes


Etats et interactions a reconstruire :

- Page hors produit : aucun etat d'interface a reconstruire.

## 8. Tableaux, code et medias

- Tableaux : 0
- Blocs `pre` : 0 · elements `code` : 0
- SVG inline : 0 · images : 0
- Icones du sprite utilisees : aucune
- Volume de texte : ~838 mots · 10 noeuds HTML

## 9. Ressources chargees

- Feuilles de style : aucune (styles inline uniquement)
- Scripts externes : aucun
- Blocs `<style>` inline : 1 · scripts inline : 0

## 10. Classes et attributs data observes

Classes distinctes : 3. Les plus frequentes :

| Classe | Occurrences |
|---|---|
| `header` | 1 |
| `status` | 1 |
| `main` | 1 |

Aucun attribut `data-*`.

## 11. Controle qualite automatique

- Titres `h1` : 0 (a verifier)
- Boutons sans texte ni aria-label : 0
- Champs identifies sans label associe : 0
- Images sans attribut alt : 0
- Liens sans texte ni aria-label : 0
- Emoji detectes : 0 (la charte du produit les proscrit)

## 12. Renvois

- Layouts et gabarits : [04_LAYOUTS_ET_STRUCTURES.md](../../../04_LAYOUTS_ET_STRUCTURES.md)
- Composants et etats : [05_COMPOSANTS_REUTILISABLES.md](../../../05_COMPOSANTS_REUTILISABLES.md) · [10_ETATS_INTERFACE.md](../../../10_ETATS_INTERFACE.md)
- Regles d'acces : [11_ETATS_CONDITIONNELS.md](../../../11_ETATS_CONDITIONNELS.md) · [17_REGLES_METIER.md](../../../17_REGLES_METIER.md)
- Captures a produire : [22_REGISTRE_CAPTURES.md](../../../22_REGISTRE_CAPTURES.md)

*Fiche generee le 2026-11-05 par `tools/extract.mjs` ; donnees brutes dans `evidence/pages.json`.
