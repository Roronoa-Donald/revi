# σ Algèbre relationnelle

> Fiche extraite du fichier `b1/fbd/chapitres/chapitre2.html` (388 lignes, 21.5 Ko, sha256 `40a35ba5b6a0`).
> Famille : **hors-produit** · sous-type : `b1` · statut : **bloque-serveur**.
> Cette fiche decrit ce que le document contient reellement ; les elements deduits du JavaScript sont signales `[deduit]` et references au document thematique.

## 1. Identite et acces

| Champ | Valeur |
|---|---|
| URL servie | `/b1/... (403)` |
| Titre du document | Chapitre 2 — Algèbre relationnelle \| FBD B1 |
| Description meta | — |
| Robots | indexable (defaut) |
| Langue / theme | `fr` / `defaut` |
| Chapitre (body) | — |
| Regle d'acces | Hors produit / archive |
| Statut de service | bloque-serveur |

## 2. Structure du document (ordre observe)

| # | Element | Classe / role | Contenu cle |
|---|---|---|---|
| 1 | nav | glass-nav | 6 liens, aria="" |
| 2 | h1 | — | σ Algèbre relationnelle |
| 3 | h2 | — | Objectifs du chapitre |
| 4 | h2 | — | Pourquoi l'algèbre relationnelle ? |
| 5 | h2 | — | Opérations unaires (1 table) |
| 6 | h2 | — | Opérations ensemblistes (2 tables) |
| 7 | h2 | — | Les jointures |
| 8 | h2 | — | La division (÷) |
| 9 | h2 | — | Arbre algébrique |
| 10 | h2 | — | Exercices guidés |
| 11 | h2 | — | Récapitulatif |
| 12 | h2 | — | Exercices du chapitre |
| 13 | table | — | 3 tableau(x) |

## 3. Hierarchie des titres

- **H1** — σ Algèbre relationnelle
  - **H2** — Objectifs du chapitre
  - **H2** — Pourquoi l'algèbre relationnelle ?
  - **H2** — Opérations unaires (1 table)
    - **H3** — σ — Sélection (sigma)
    - **H3** — π — Projection (pi)
    - **H3** — ρ — Renommage (rho)
  - **H2** — Opérations ensemblistes (2 tables)
    - **H3** — Les 4 opérations
  - **H2** — Les jointures
    - **H3** — Types de jointures
  - **H2** — La division (÷)
  - **H2** — Arbre algébrique
  - **H2** — Exercices guidés
      - **H4** — Enchaîner sélection, projection et jointure
      - **H4** — Différence et division relationnelles
  - **H2** — Récapitulatif
    - **H3** — 🧠 Les 8 opérations de l'algèbre relationnelle
  - **H2** — Exercices du chapitre

## 4. Navigation et liens

| Zone | Classe | Liens |
|---|---|---|
| nav | `glass-nav` | AutoBot → `../index.html`<br>Accueil → `../index.html`<br>Formules → `formules.html`<br>Cartes → `cartes.html`<br>Simulateur → `simulateur-examen.html`<br>Exercices → `../exercices/exercices.html` |

Liens sortants : **20** (externes : 0).

| Libelle | href | Cible resolue | Type |
|---|---|---|---|
| Aller au contenu | `#main-content` | `#main-content` | ancre |
| AutoBot | `../index.html` | `b1/fbd/index.html` | interne |
| Accueil | `../index.html` | `b1/fbd/index.html` | interne |
| Formules | `formules.html` | `b1/fbd/chapitres/formules.html` | interne |
| Cartes | `cartes.html` | `b1/fbd/chapitres/cartes.html` | interne |
| Simulateur | `simulateur-examen.html` | `b1/fbd/chapitres/simulateur-examen.html` | interne |
| Exercices | `../exercices/exercices.html` | `b1/fbd/exercices/exercices.html` | interne |
| Ch.1 | `chapitre1.html` | `b1/fbd/chapitres/chapitre1.html` | interne |
| Ch.2 | `chapitre2.html` | `b1/fbd/chapitres/chapitre2.html` | interne |
| Ch.3 | `chapitre3.html` | `b1/fbd/chapitres/chapitre3.html` | interne |
| Ch.4 | `chapitre4.html` | `b1/fbd/chapitres/chapitre4.html` | interne |
| Ch.5 | `chapitre5.html` | `b1/fbd/chapitres/chapitre5.html` | interne |
| Ch.6 | `chapitre6.html` | `b1/fbd/chapitres/chapitre6.html` | interne |
| Chapitre 1 | `chapitre1.html` | `b1/fbd/chapitres/chapitre1.html` | interne |
| Chapitre 3 | `chapitre3.html` | `b1/fbd/chapitres/chapitre3.html` | interne |

## 5. Formulaires et champs

Aucun formulaire dans cette page.
## 6. Boutons et controles interactifs

| Libelle | type | id | classes | aria-label | Etat initial | data-* |
|---|---|---|---|---|---|---|
| (icone) |  | theme-toggle | `—` | Mode sombre | actif | — |
| (icone) |  | hamburger-btn | `hamburger-btn` | Menu | actif | — |
| (icone) |  | mobile-nav-close | `mobile-nav-close` | — | actif | — |

## 7. Composants pedagogiques et etats observes


Etats et interactions a reconstruire :

- Page hors produit : aucun etat d'interface a reconstruire.

## 8. Tableaux, code et medias

- Tableaux : 3 (0 lignes / 4 en-tetes ; 0 lignes / 3 en-tetes ; 0 lignes / 4 en-tetes)
- Blocs `pre` : 13 · elements `code` : 6
- SVG inline : 0 · images : 0
- Icones du sprite utilisees : aucune
- Volume de texte : ~1496 mots · 348 noeuds HTML

## 9. Ressources chargees

- Feuilles de style : `https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css`, `https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=JetBrains+Mono:wght@400;500;700&display=swap`, `../../assets/css/style.css`
- Scripts externes : `../../assets/js/main.js`, `../../assets/js/gamification.js`, `../../assets/js/chapter-exercises.js`, `../../assets/js/download.js`
- Blocs `<style>` inline : 1 · scripts inline : 2

## 10. Classes et attributs data observes

Classes distinctes : 60. Les plus frequentes :

| Classe | Occurrences |
|---|---|
| `fas` | 26 |
| `chapter-section` | 10 |
| `reveal-on-scroll` | 10 |
| `section-title` | 9 |
| `code-block` | 7 |
| `code-header` | 7 |
| `fa-book-open` | 6 |
| `info-box` | 5 |
| `mnemonic-box` | 3 |
| `mnemonic-title` | 3 |
| `concept-card` | 3 |
| `styled-table` | 3 |
| `fa-solid` | 2 |
| `fa-dumbbell` | 2 |
| `fa-filter` | 2 |
| `tip-box` | 2 |
| `warning-box` | 2 |
| `example-box` | 2 |
| `btn-nav` | 2 |
| `skip-link` | 1 |

Aucun attribut `data-*`.

## 11. Controle qualite automatique

- Titres `h1` : 1
- Boutons sans texte ni aria-label : 1
- Champs identifies sans label associe : 0
- Images sans attribut alt : 0
- Liens sans texte ni aria-label : 0
- Emoji detectes : 23 (la charte du produit les proscrit)

## 12. Renvois

- Layouts et gabarits : [04_LAYOUTS_ET_STRUCTURES.md](../../../04_LAYOUTS_ET_STRUCTURES.md)
- Composants et etats : [05_COMPOSANTS_REUTILISABLES.md](../../../05_COMPOSANTS_REUTILISABLES.md) · [10_ETATS_INTERFACE.md](../../../10_ETATS_INTERFACE.md)
- Regles d'acces : [11_ETATS_CONDITIONNELS.md](../../../11_ETATS_CONDITIONNELS.md) · [17_REGLES_METIER.md](../../../17_REGLES_METIER.md)
- Captures a produire : [22_REGISTRE_CAPTURES.md](../../../22_REGISTRE_CAPTURES.md)

*Fiche generee le 2026-11-05 par `tools/extract.mjs` ; donnees brutes dans `evidence/pages.json`.
